package fr.insa.damien;

public abstract class Figure {

    //attributs
    private String idFig; // definit dans les subclasses
    //statics
        //aucuns

    //constructeurs
        //aucun


    // getter et setter


    public String getIdFig() {
        return idFig;
    }

    public void setIdFig(String idFig) {
        this.idFig = idFig;
    }

//Methodes abstraites

    //toute figure a une distance minimale avec un point

    public abstract double distancePoint(Point A);

    //max et min definie pour toute figure

    public abstract double maxX();
    public abstract double minX();
    public abstract double maxY();
    public abstract double minY();
}
