package fr.insa.damien;


import java.util.Locale;
import java.util.Scanner;

public class MainClass {


            public static void main(String[] args) {

                menu();

            }


    public static Figure[] menu(){
        Scanner sc = new Scanner(System.in).useLocale(Locale.US);

        Figure ret [] = entreTabFigure();  // on est obligé d'entrer un tableau our pouvoir choisir de visualiser, ou de calculer la distance

        String reponse;

        while (true) {

            System.out.println(   "\n1) Re rentrer des figures stockées dans un tableau" +
                                "\n2) Afficher les figures entrées" +
                                "\n3) calculer la distance entre une figure entrée et un nouveau point" +
                                "\nq) Pour quitter\n" );
            reponse=sc.nextLine();


            if (reponse.equals("1"))
                ret = entreTabFigure();

            else if (reponse.equals("2")) {
                for (int i = 0; i < ret.length; i++) {
                    System.out.println("A la position " + i + " du tableau il y a la Figure suivante :");
                    System.out.println(ret[i]);
                }
            }

            else if (reponse.equals("3")) {
                System.out.println("Entrez l'indice de la Figure puis les coordonées du point ");
                System.out.println("La distance entre la figure et le point est de : " + ret[sc.nextInt()].distancePoint(new Point(sc.nextDouble(), sc.nextDouble())));
            }

            else if (reponse.equals("q"))
                break;

        }
        return ret;

    }


    public static Figure[] entreTabFigure(){
        Scanner sc = new Scanner(System.in).useLocale(Locale.US);
        System.out.println("Combien de Figures voulez vous entrer ?");

        Figure ret[] = new Figure[sc.nextInt()];

        for (int i = 0; i< ret.length ; i++ ){
            ret[i]=entreFigure();
        }
        return ret;
    }

    public static Figure entreFigure(){
        Scanner sc = new Scanner(System.in).useLocale(Locale.US);
        Figure ret ;

        String reponse;

        System.out.println("Création d'une figure :\n" +
                "1)Point \n" +
                "2)Segment \n");
        reponse=sc.nextLine();

        if (reponse.equals("1")){ //Cas ou l'on choisi un point
            ret = new Point();

        }
        else if (reponse.equals("2")){ // Cas ou l'on choisis un segment
            ret = new Segment();
        }

        else {
            throw new IllegalArgumentException("La valeur entrée dans le menu est incorecte");
        }

        return ret;

    }

}


