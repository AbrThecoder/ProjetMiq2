package fr.insa.damien;

public class Segment extends Figure {
    //attributs
    private Point p1;
    private Point p2;
    //statics
    private static int compteurId;

    //constructeurs

    public Segment(Point p1, Point p2) {
        this.p1 = p1;
        this.p2 = p2;
        compteurId++;
        super.setIdFig("Segment_N°"+ compteurId);
    }

    public Segment(){
        System.out.println("Pour créer le segment nous allons créer 2 points");
        System.out.println("Point 1 :");
        this.p1=new Point();
        System.out.println("Point 2 :");
        this.p2= new Point();
        super.setIdFig("Segment_N°"+ compteurId);
        compteurId++;
    }

    //getter et setter

    public Point getP1() {
        return p1;
    }

    public void setP1(Point p1) {
        this.p1 = p1;
    }

    public Point getP2() {
        return p2;
    }

    public void setP2(Point p2) {
        this.p2 = p2;
    }

    //methode internes privées

    private double min(double A, double B){
        if (A<B)
            return A;
        else
            return B;

    }

    private double max(double A, double B){
        if(A<B)
            return B;
        else
            return A;

    }

    //methodes max, min

    public double maxX(){
        return max(this.p1.getX(),this.p2.getX());
    }

    public double minX(){
        return min(this.p1.getX(),this.p2.getX());
    }

    public double maxY(){
        return max(this.p1.getY(),this.p2.getY());
    }

    public double minY(){
        return min(this.p1.getY(),this.p2.getY());
    }

    //distance entre un segment et un segment

    public double distancePoint(Point p3) {
        //cf documentation pdf
        double up = (p3.getX() - this.p1.getX()) * (this.p2.getX() - this.p1.getX()) + (p3.getY() - this.p1.getY()) * (this.p2.getX() - this.p1.getY());
        up /= Math.pow((this.p2.getX() - this.p1.getX()), 2) + Math.pow((this.p2.getY() - this.p1.getY()), 2);

        //3 cas differents selon up cf doc
        if (up < 0)
            return this.p1.distancePoint(p3);
        if (up > 1)
            return this.p2.distancePoint(p3);
        else {
            Point p4 = new Point(this.p1.getX() + up * (this.p2.getX() - this.p1.getX()),
                    this.p1.getY() + up * (this.p2.getY() - this.p1.getY()));
            return p3.distancePoint(p4);
        }
    }

    @Override
    public String toString() {
        return "Segment{" +
                "p1=" + p1 +
                ", p2=" + p2 +
                ", idFig='" + super.getIdFig() + '\'' +
                '}';
    }

}
