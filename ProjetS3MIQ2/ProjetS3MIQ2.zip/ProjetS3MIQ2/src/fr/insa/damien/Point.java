package fr.insa.damien;

import java.util.Locale;
import java.util.Scanner;

public class Point extends Figure{
    //attributs
    private double x;
    private double y;
    //statics
    private static int  compteurId;
    private static Scanner sc=new Scanner(System.in).useLocale(Locale.US);

    //constructeurs

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
        super.setIdFig("Point_N°"+compteurId);
        compteurId++;
    }

    public Point (){
        System.out.println("Création d'un Point : veuillez entrer l'abcsisse (x) et l'ordoonée (y) du point ");
        System.out.println("x=");
        this.x=sc.nextDouble(); // attention la locale fr pour les double est avec une virgule ex: double A =12,3;  fonctionne mais pas double A =12.3;
        System.out.println("y=");
        this.y=sc.nextDouble();
        super.setIdFig("Point_N°"+compteurId);
        compteurId++;
    }

    //getter et setter

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    //methode min et max

    public double maxX(){
        return x;
    }

    public double maxY(){
        return y;
    }

    public double minX(){
        return y;
    }

    public double minY(){
        return y;
    }

    //methodes internes

    private static double sommeQuadratique(double A,double B){
        return Math.sqrt(Math.pow(A,2)+Math.pow(B,2));
    }

    // distance netre 2 points

    public double distancePoint(Point p){
        // cf sommeQuadratique definie comme public dans la superclasse Figure
        return sommeQuadratique(this.x-p.getX(),this.y-p.getY());
    }

    @Override
    public String toString() {
        return "Point{" +
                "x=" + x +
                ", y=" + y +
                ", idFig='" + super.getIdFig() + '\'' +
                '}';
    }


}
