package fr.damien.insa;
import java.io.*;
public class MainClass {

    public static void main(String[] args) {

        try {

            BufferedWriter flux = new BufferedWriter(new FileWriter("Etudiants.txt",true));
            

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
